//
//  School.swift
//  App
//
//  Created by Rujira Petrung on 15/4/20.
//

import Vapor
import FluentPostgreSQL

final class School: Codable {
    
    typealias Database = PostgreSQLDatabase
    
    var id: UUID?
    var name: String
    
    init(name: String) {
        self.name = name
    }
}

extension School: PostgreSQLUUIDModel {}
extension School: Content {}
extension School: Migration {}
extension School: Parameter {}

extension School {
    var grades: Children<School, Grade> {
        return children(\.schoolID)
    }
}
