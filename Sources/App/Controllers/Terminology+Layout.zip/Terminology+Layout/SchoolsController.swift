//
//  SchoolsController.swift
//  App
//
//  Created by Rujira Petrung on 15/4/20.
//

import Vapor
import Fluent

struct SchoolsController: RouteCollection {
    
    func boot(router: Router) throws {
        
        let schoolsRoutes = router.grouped("api", "schools")
        
        schoolsRoutes.get(use: getAllHandler)
        schoolsRoutes.post(School.self, use: createHandler)
        schoolsRoutes.get(School.parameter, use: getHandler)
        schoolsRoutes.put(School.parameter, use: updateHandler)
        schoolsRoutes.delete(School.parameter, use: deleteHandler)
        
        //Parent-Child Relationships APIs
        //School-Grade
        schoolsRoutes.get(School.parameter, "grades", use: getGradesHandler)
        
    }
    
    //Create (POST)
    func createHandler(_ req: Request, school: School) throws -> Future<School> {

        return school.save(on: req)
    }
    
    //Retrieve All (GET)
    func getAllHandler(_ req: Request) throws -> Future<[School]> {
        return School.query(on: req).all()
    }
    
    //Get Single (POST)
    func getHandler(_ req: Request) throws -> Future<School> {
        return try req.parameters.next(School.self)
    }
    
    //Update Single (PUT)
    func updateHandler(_ req: Request) throws -> Future<School> {
        return try flatMap(
            to: School.self,
            req.parameters.next(School.self), req.content.decode(School.self)
        ) { school, updatedSchool in
            school.name = updatedSchool.name
           
            return school.save(on: req)
        }
    }
    
    //Delete Single (DELETE)
    func deleteHandler(_ req: Request) throws -> Future<HTTPStatus> {
        return try req
        .parameters
        .next(School.self)
        .delete(on: req)
        .transform(to: .noContent)
    }
    
    //Child-Parent Relationships School-Grade
    
    func getGradesHandler(_ req: Request) throws -> Future<[Grade]> {
        return try req
            .parameters.next(School.self)
            .flatMap(to: [Grade].self) { school in
                try school.grades.query(on: req).all()
        }
    }
    
}
